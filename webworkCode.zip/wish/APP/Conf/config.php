<?php
return array(
	//'配置项'=>'配置值'
	'APP_GROUP_LIST'=>'Index,Admin',
	'DEFAULT_GROUP'=>'Index',
	
	'DB_HOST'=> '127.0.0.1',
	'DB_USER'=> 'root',
	'DB_PWD'=>'',
	'DB_NAME'=>'think',
	'DB_PREFIX'=>'hd_',
	//模板路径
	'TMPL_FILE_DEPR'=>'_',
	//点语法默认解析
	'TMPL_VAR_IDENTIFY'=>'array',
);
?>