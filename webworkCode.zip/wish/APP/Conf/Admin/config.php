<?php

return array(
   'TMPL_PARSE_STRING'=>array(
   
     '__PUBLIC__'=>__ROOT__.'/'.APP_NAME.'/Tpl/Admin/Public',
     '__PUBLI__'=>__ROOT__.'/'.APP_NAME.'/Tpl/Admin'
   ),


);


?>