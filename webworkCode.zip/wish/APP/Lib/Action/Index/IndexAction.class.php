<?php
  Class IndexAction extends Action{
  	public function index(){
  		echo 'this is index';
  	}
	public function handle(){
		if(!IS_AJAX) halt('页面不存在');
		//p(I('post.'));
		//$username=I("username");
		$data=array(
		   'username'=>I('username'),
		   'content'=>I('content')
		
		
		);
		
		
		
	}
  }



?>