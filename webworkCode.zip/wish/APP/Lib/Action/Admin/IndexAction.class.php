<?php
   Class IndexAction extends CommomAction{
   	  Public function index(){
   		$this->assign('student',M('student')->select());	
		$this->assign('score',M('score')->select())->display();	
   	}
	  public function indext(){
	  	$this->assign('teacher',M('teacher')->select())->display('indext');
	  	
	  }
	  
	 public function account(){
	 	$this->assign('student',M('student')->select())->display();	
	 }
	 public function accountT(){
	 	$this->assign('teacher',M('teacher')->select())->display();
	 }
	 public function select(){
	 	$this->assign('score',M('score')->select())->display();	
	 }
	 public function selectT(){
	 	$this->assign('teacher',M('teacher')->select())->display('selectT');	
	 }
	public function handle(){
		 if(!IS_POST) _404('页面不存在',U('index'));
	     $data=array(
	      'name'=>I('name')
	    
      	 );
		 
		 if(M('score')->data($data)->add())
		 {
		 	$this->success('选课成功！');
		 }else{
		 	$this->error('发布失败请重试！');
		 }
   }
	 public function handleT(){
		 if(!IS_POST) _404('页面不存在',U('index'));
	     $data=array(
	      'name'=>I('name'),
	      'score'=>I('score')
      	 );
		 
		 if(M('score')->data($data)->add())
		 {
		 	$this->success('录入成绩成功！');
		 }else{
		 	$this->error('录入失败，请重试！');
		 }
   }
	 public function password(){
	 	$uid=session("uid");
		$pwd=I('newpwd','','md5');
		$data=array(
		   'password'=>$pwd
		);
		
		if(M("user")->where(array("id"=>$uid))->save($data)){
			$this->success('修改密码成功!');
		}else{
			$this->error('修改失败，请重新修改！');
		}
	 }
	  public function passwordT(){
	 	$uid=session("uidd");
		$pwd=I('newpwd','','md5');
		$data=array(
		   'password'=>$pwd
		);
		
		if(M("usert")->where(array("id"=>$uid))->save($data)){
			$this->success('修改密码成功!');
		}else{
			$this->error('修改失败，请重新修改！');
		}
	 }
	 
	
   }




?>