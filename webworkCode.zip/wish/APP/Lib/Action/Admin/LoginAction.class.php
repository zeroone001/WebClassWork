<?php
/*后台登陆控制器*/
  Class LoginAction extends Action{
  	Public function index(){
  		$this->display();
  	}
	public function login(){
		if(!IS_POST) halt('页面不存在');
		
		$username=I('username');
		$pwd=I('password','','md5');
		
		$user=M('user')->where(array('username'=>$username))->find();
		$usert=M('usert')->where(array('username'=>$username))->find();
	if($user){
		if($user['password']!=$pwd){
			$this->error('账号或者密码错误');
		}
		
		$data=array(
		  'id'=>$user['id'],
		  'logintime'=>time(),
		  'loginip'=>get_client_ip(),
		  
		);
		M('user')->save($data);
		session('uid',$user['id']);
		session('username',$user['username']);		
		session('loginip',$user['loginip']);
		
		 $this->redirect('Admin/Index/index');
		}
	elseif($usert){
				if($usert['password']!=$pwd){
				$this->error('账号或者密码错误');
			}
			
			$data=array(
			  'id'=>$usert['id'],
			  'logintime'=>time(),
			  'loginip'=>get_client_ip(),
			  
			);
			M('user')->save($data);
			session('uidd',$usert['id']);
			session('username',$usert['username']);		
			session('loginip',$usert['loginip']);
			
			 $this->redirect('Admin/Index/indext');
			}
	}
	 
	
	
	
	
  }



?>