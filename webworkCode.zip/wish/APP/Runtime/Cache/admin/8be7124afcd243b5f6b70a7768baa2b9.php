<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>山东大学(威海)管理系统</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />    
    
    <link href="__PUBLIC__/css/bootstrap.min.css" rel="stylesheet" />
    <link href="__PUBLIC__/css/bootstrap-responsive.min.css" rel="stylesheet" />
    
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet" />
    <link href="__PUBLIC__/css/font-awesome.css" rel="stylesheet" />
    
    <link href="__PUBLIC__/css/adminia.css" rel="stylesheet" /> 
    <link href="__PUBLIC__/css/adminia-responsive.css" rel="stylesheet" /> 
    
    <link href="__PUBLIC__/css/pages/plans.css" rel="stylesheet" /> 

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
	
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>

<body>
	
<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			
			
			<a class="brand" href="#">山东大学（威海）</a>
			
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->

<div id="content">
	
	<div class="container">
		
		<div class="row">
			
			<div class="span3">
				
					<div class="account-container">
				
					<div class="account-avatar">
						<img src="__PUBLIC__/img/headshot.png" alt="" class="thumbnail" />
					</div> <!-- /account-avatar -->
				<?php if(is_array($teacher)): foreach($teacher as $key=>$v): ?><div class="account-details">
					
						<span class="account-name"><?php echo ($v["username"]); ?></span>
						
						<span class="account-role"><?php echo ($v["content"]); ?></span>
						
						<span class="account-actions">
							<?php echo ($v["sex"]); ?>
						</span>
					
					</div> <!-- /account-details --><?php endforeach; endif; ?>
				</div> <!-- /account-container -->
				
				<hr />
				
				<ul id="main-nav" class="nav nav-tabs nav-stacked">
					
				
					<li >
						<a href="<?php echo U('indext');?>">
							<i class="icon-home"></i>
							首页 		
						</a>
					</li>
					
					<li class="active">
						<a href="#">
							<i class="icon-user"></i>
							修改密码							
						</a>
					</li>
					<li>
						<a href="<?php echo U('selectT');?>">
							<i class="icon-th-list"></i>
							录入成绩	
						</a>
					</li>			
				</ul>	
				
				<hr />
			
				<br />
		
			</div> <!-- /span3 -->
			
			<div class="span9">
				
				<h1 class="page-title">
					<i class="icon-th-large"></i>
				修改密码					
				</h1>
				
				<div class="row">
					
					<div class="span9">
				
						<div class="widget">
							
							<div class="widget-header">
								<h3>修改密码</h3>
							</div> <!-- /widget-header -->
									
							<div class="widget-content">
								
								<div class="tabbable">
						<ul class="nav nav-tabs">
						  <li class="active">
						    <a href="#" data-toggle="tab">Password</a>
						  </li>
						  
						</ul>
						
						<br />
						
							<div class="tab-content">
								<div class="tab-pane active" id="1">
								<form id="edit-profile" class="form-horizontal" method="post" action="<?php echo U('Admin/Index/passwordT');?>" />
									<fieldset>
										
										
										
										<div class="control-group">											
											<label class="control-label" for="newpwd">newPassword</label>
											<div class="controls">
												<input type="password" class="input-medium" id="newpwd" name="newpwd" />
											</div> <!-- /controls -->				
										</div> <!-- /control-group -->
										
											<br />
										
										<div class="form-actions">
										<input type="submit" class="btn btn-primary" value="保存"> 
											
										</div> <!-- /form-actions -->
									</fieldset>
								</form>
								</div>								
							</div>						  
						</div>
							
							</div> <!-- /widget-content -->
							
						</div> <!-- /widget -->
						
					</div> <!-- /span9 -->
					
				</div> <!-- /row -->
				
			</div> <!-- /span9 -->
			
			
		</div> <!-- /row -->
		
	</div> <!-- /container -->
	
</div> <!-- /content -->
					
	
<div id="footer">
	
	<div class="container">				
		<hr />
		<p>&copy; 2015 Web Class.</p>
	</div> <!-- /container -->
	
</div> <!-- /footer -->

<script src="__PUBLIC__/js/jquery-1.7.2.min.js"></script>
<script src="__PUBLIC__/js/bootstrap.js"></script>

 </body>
</html>