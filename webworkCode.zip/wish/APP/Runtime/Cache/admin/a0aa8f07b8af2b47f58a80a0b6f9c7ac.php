<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>山东大学(威海)管理系统</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />    
    
    <link href="__PUBLIC__/css/bootstrap.min.css" rel="stylesheet" />
    <link href="__PUBLIC__/css/bootstrap-responsive.min.css" rel="stylesheet" />
    
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet" />
    <link href="__PUBLIC__/css/font-awesome.css" rel="stylesheet" />
    
    <link href="__PUBLIC__/css/adminia.css" rel="stylesheet" /> 
    <link href="__PUBLIC__/css/adminia-responsive.css" rel="stylesheet" /> 
    
    <link href="__PUBLIC__/css/pages/login.css" rel="stylesheet" /> 

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
	
  </head>
<body>
	
<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			<a class="brand" href="#">山东大学（威海）</a>
			
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->


<div id="login-container">

	<div id="login-header">
		
		<h3>Login</h3>
		
	</div> <!-- /login-header -->
	
	<div id="login-content" class="clearfix">
	
	<form class="" action="<?php echo U('Admin/Login/login');?>" method="post">
				<fieldset>
					<div class="control-group">
						<label class="control-label" for="username" >Username</label>
						<div class="controls">
							<input type="text" class="" id="username"  name="username" placeholder="学号"/>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="password">Password</label>
						<div class="controls">
							<input type="password" class="" id="password" name="password" placeholder="身份证后六位"/>
						</div>
					</div>
				</fieldset>
				
				<div id="remember-me" class="pull-left">
					<input type="checkbox" name="remember" id="remember" />
					<label id="remember-label" for="remember">Remember Me</label>
				</div>
				
				<div class="pull-right">
					<input type="submit" value="Login" class="btn btn-warning btn-large" id="login"  style="width: 110%;height: 25px;"/>
					<!--<a href="#" class="btn btn-warning btn-large" id="login">
						Login
					</a>-->
				</div>
			</form>
			
		</div> <!-- /login-content -->
		
</div> <!-- /login-wrapper -->

<script src="./js/jquery-1.7.2.min.js"></script>

<script src="./js/bootstrap.js"></script>
<script>
	$(function(){
         var username=$('#username');
         var password=$('#password');
		$("#login").bind("click",function(){
			
			if($("#username").val()===null)
			{
				$("#username").css("borderColor","red");
			}
			if($("#password").val()===null)
			{
				$("#password").css("borderColor","red");
			}
			
		});
		
	});
</script>

  </body>
</html>